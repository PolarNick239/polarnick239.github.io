package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class PauseListener implements ActionListener {

    public PauseListener() {
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        // TODO 21: добавить возможность ставить игру на паузу
        System.out.println("Пауза еще не поддержана т.к. не выполнено TODO 21!");
    }
}
