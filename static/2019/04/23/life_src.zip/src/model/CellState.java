package model;

public enum CellState {
    DEAD,
    ALIVE,
}
